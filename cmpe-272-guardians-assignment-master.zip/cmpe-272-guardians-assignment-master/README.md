## Team WALK:
  William Forsythe,
  Amulya Kishore,
  Lucero Davalos,
  Kostiantyn Pavlenko.

## Build Status
[![CircleCI](https://circleci.com/gh/amulyakish/cmpe-272-guardians-assignment.svg?style=svg)](https://circleci.com/gh/amulyakish/cmpe-272-guardians-assignment)
