export const CONFIG = {
    domain: 'assignment-walk.auth0.com',
    clientId: 'reDXRyzcftLqoNzvmdmNuhmKnEV53Nqo',
    audience: 'http://walk/api',
    callbackUrl: 'http://54.183.57.23/callback',
    logoutUrl : 'http://54.183.57.23/logout',
    APIBaseUrl : 'http://54.183.57.23:8080'
}
